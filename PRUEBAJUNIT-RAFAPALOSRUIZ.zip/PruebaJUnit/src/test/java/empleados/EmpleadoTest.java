package empleados;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;




class EmpleadoTest {
	Empleado e1;
	Empleado e2;
	
	@BeforeEach
	void setUp() throws Exception {
		e1 = new Empleado();
		e2 = new Empleado();
	}
	@ParameterizedTest(name = "Test getNombre")
	@CsvSource ({
		"Rafael, Rafael",
		"Daniel, Daniel",
		"Juan, Juan"
	})
	void testGetNombre(String nombre, String result) {
		e1 = new Empleado(nombre,"Palos");
		assertEquals(result, e1.getNombre());
	}

	@ParameterizedTest(name = "Test getApellido")
	@CsvSource ({
		"Palos,	Palos",
		"Ruiz, Ruiz",
		"Garcia, Garcia"
	})
	void testGetApellido(String apellido, String result) {
		e1 = new Empleado("Rafael", apellido);
		assertEquals(result, e1.getApellido());
	}

	@ParameterizedTest(name = "Test getEdad")
	@CsvSource ({
		"19, 19",
		"40, 40",
		"56, 56"
	})
	void testGetEdad(int edad, int result) {
		e1 = new Empleado("Rafael", "Palos", edad);
		assertEquals(result, e1.getEdad());
	}

	@ParameterizedTest(name = "Test getSalario")
	@CsvSource ({
		"1250, 1250",
		"1100, 1100",
		"2300, 2300"
	})
	void testGetSalario(double salario, double result) {
		e1 = new Empleado("Rafael", "Palos", 19, salario);
		assertEquals(result, e1.getSalario());
	}

	@ParameterizedTest(name = "Test Plus")
	@CsvSource ({
		"Rafael, Palos, 19, 1250, 1000, false",
		"Daniel, Ruiz, 40, 1100, 900, false",
		"Juan, Garcia, 56, 2300, 1500, true"
	})
	void testPlus(String nombre, String apellido, int edad, double salario, double sueldoPlus, boolean result) throws Exception {
		e1 = new Empleado(nombre, apellido, edad, 1250);
		assertEquals(result, e1.plus(sueldoPlus));
	}

	@ParameterizedTest(name = "Test EqualsEmpleado")
	@CsvSource ({
		"Rafael, Palos, true",
		"Daniel, Ruiz, true",
		"Juan, Garcia, true"
	})
	void testEqualsEmpleado(String nombre, String apellido, boolean result) {
		e1 = new Empleado(nombre, apellido);
		e2 = new Empleado(nombre, apellido);
		assertEquals(result, e1.equals(e2));
	}

	@ParameterizedTest(name = "Test CompareTo")
	@CsvSource ({
		"Rafael, Palos, 19, 1",
		"Daniel, Ruiz, 40, 0",
		"Juan, Garcia, 56, -1"
	})
	void testCompareTo(String nombre, String apellido, int edad, int result) {
		e1 = new Empleado("Paquito", "Fernandez", 40);
		e2 = new Empleado(nombre, apellido, edad);
		assertEquals(result, e1.compareTo(e2));
	}

	@ParameterizedTest(name = "Test ToString")
	@CsvSource ({
		"Rafael, Palos, 19, 1250",
		"Daniel, Ruiz, 40, 1100",
		"Juan, Garcia, 56, 2300"
	})
	void testToString(String nombre, String apellido, int edad, double salario) {
		e1 = new Empleado(nombre, apellido, edad, salario);
		equals("El empleado se llama "+nombre+" "+apellido+" con "+edad+" a�os " +
                "y un salario de "+salario);
	}

	@ParameterizedTest(name = "Test EmpleadoStringString")
	@CsvSource ({
		"Rafael, Palos, Rafael, Palos",
		"Daniel, Ruiz, Daniel, Ruiz",
		"Juan, Garcia, Juan, Garcia"
	})
	void testEmpleadoStringString(String nombre, String apellido, String result1, String result2) {
		e1 = new Empleado(nombre, apellido);
		assertEquals(result1, e1.getNombre());
		assertEquals(result2, e1.getApellido());
	}

	@ParameterizedTest(name = "Test EmpleadoStringStringInt")
	@CsvSource ({
		"Rafael, Palos, 19, Rafael, Palos, 19",
		"Daniel, Ruiz, 40, Daniel, Ruiz, 40",
		"Juan, Garcia, 56, Juan, Garcia, 56"
	})
	void testEmpleadoStringStringInt(String nombre, String apellido, int edad, String result1, String result2, int result3) {
		e1 = new Empleado(nombre, apellido, edad);
		assertEquals(result1, e1.getNombre());
		assertEquals(result2, e1.getApellido());
		assertEquals(result3, e1.getEdad());
	}

	@ParameterizedTest(name = "Test EmpleadoStringStringIntDouble")
	@CsvSource ({
		"Rafael, Palos, 19, 1250, Rafael, Palos, 19, 1250",
		"Daniel, Ruiz, 40, 1100, Daniel, Ruiz, 40, 1100",
		"Juan, Garcia, 56, 2300, Juan, Garcia, 56, 2300"
	})
	void testEmpleadoStringStringIntDouble(String nombre, String apellido, int edad, double salario, String result1, String result2, int result3, double result4) {
		e1 = new Empleado(nombre, apellido, edad, salario);
		assertEquals(result1, e1.getNombre());
		assertEquals(result2, e1.getApellido());
		assertEquals(result3, e1.getEdad());
		assertEquals(result4, e1.getSalario());
	}

}
