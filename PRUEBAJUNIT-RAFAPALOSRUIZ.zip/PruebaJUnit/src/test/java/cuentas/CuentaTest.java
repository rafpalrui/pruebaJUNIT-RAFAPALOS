package cuentas;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CuentaTest {

	Cuenta c;
	
	@BeforeEach
	void setUp() throws Exception {
		c = new Cuenta("0424617","CuentaRafael");		
	}

	@Test
	void testIngresarPositivo() throws IngresoNegativoException {
		c.ingresar("Ingreso positivo", 220);
		assertEquals(220, c.getSaldo());
	}

	@Test
	void testIngresarNegativo() {
		IngresoNegativoException thrown = assertThrows(
				IngresoNegativoException.class, 
	            () -> c.ingresar("Ingreso negativo", -220));
		assertEquals("No se puede ingresar una cantidad negativa", thrown.getMessage());
	}
	
	@Test
	void testRetiradaIgualitaria() throws IngresoNegativoException, SaldoInsuficienteException {
		testIngresarPositivo();
		c.retirar("Retirada igual", 220);
		assertEquals(0, c.getSaldo());
	}
	
	@Test
	void testRetiradaInferior() throws IngresoNegativoException, SaldoInsuficienteException {
		testIngresarPositivo();
		c.retirar("Retirada igual", 100);
		assertEquals(120, c.getSaldo());
		
	}
	
	@Test
	void testRetiradaSuperior() throws IngresoNegativoException, SaldoInsuficienteException {
		testIngresarPositivo();
		SaldoInsuficienteException thrown = assertThrows(
				SaldoInsuficienteException.class, 
	            () -> c.retirar("Retirar negativo", 300));
		assertEquals("Saldo insuficiente", thrown.getMessage());
	}

	@Test
	void testGetSaldo() throws IngresoNegativoException {
		testIngresarPositivo();
		assertEquals(220, c.getSaldo());
	}

	@Test
	void testAddMovimiento() {
		Movimiento m = new Movimiento();
		m.setConcepto("ConceptoRealizado");
		m.setImporte(200);
		c.addMovimiento(m);
		assertEquals(c.mMovimientos.get(0), c.mMovimientos.get(0));
	}

}
