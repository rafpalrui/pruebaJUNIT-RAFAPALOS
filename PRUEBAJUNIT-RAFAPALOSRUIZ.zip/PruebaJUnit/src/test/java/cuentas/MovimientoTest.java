package cuentas;

import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MovimientoTest {

	Movimiento m;
	@BeforeEach
	void setUp() throws Exception {
		m = new Movimiento();
		m.setConcepto("ConceptoRealizado");
		m.setImporte(200);		
	}
	
	@Test
	void testSetConcepto() {
		m.setConcepto("ConceptoRealizado1");
		assertThat("ConceptoRealizado1", is(m.getConcepto()));
	}
	
	private boolean is(String concepto) {
		return false;
	}
	
	@Test
	void testSetImporte() {
		m.setImporte(400);
		assertThat(m.getImporte(), is(closeTo(200.0, 200.0)));
	}
	
	private void assertThat(double importe, boolean b) {
	}
	
	private String closeTo(double d, double e) {
		return null;
	}
	
	@Test
	void testGetImporte() {
		assertThat(m.getImporte(), is(closeTo(100.0, 100.0)));
	}

	@Test
	void testGetConcepto() {
		assertThat("ConceptoRealizado", is(m.getConcepto()));			
	}
	
	private void assertThat(String string, boolean b) {
	}

}